#ifndef _AMSI_H_
#define _AMSI_H_
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

DECLARE_HANDLE(HAMSICONTEXT);
DECLARE_HANDLE(HAMSISESSION);

typedef enum AMSI_RESULT {
    AMSI_RESULT_CLEAN = 0,
    AMSI_RESULT_NOT_DETECTED = 1,
    AMSI_RESULT_BLOCKED_BY_ADMIN_START = 0x4000,
    AMSI_RESULT_BLOCKED_BY_ADMIN_END = 0x4fff,
    AMSI_RESULT_DETECTED = 32768
} AMSI_RESULT;

#define AmsiResultIsMalware(r) ((r) >= AMSI_RESULT_DETECTED)

typedef enum AMSI_ATTRIBUTE {
    AMSI_ATTRIBUTE_APP_NAME = 0,
    AMSI_ATTRIBUTE_CONTENT_NAME = 1,
    AMSI_ATTRIBUTE_CONTENT_SIZE = 2,
    AMSI_ATTRIBUTE_CONTENT_ADDRESS = 3,
    AMSI_ATTRIBUTE_SESSION = 4
} AMSI_ATTRIBUTE;

HRESULT WINAPI AmsiInitialize(LPCWSTR appName, HAMSICONTEXT* amsiContext);
VOID WINAPI AmsiUninitialize(HAMSICONTEXT amsiContext);
HRESULT WINAPI AmsiOpenSession(HAMSICONTEXT amsiContext, HAMSISESSION* amsiSession);
VOID WINAPI AmsiCloseSession(HAMSICONTEXT amsiContext, HAMSISESSION amsiSession);
HRESULT WINAPI AmsiScanBuffer(HAMSICONTEXT amsiContext, PVOID buffer, ULONG length, LPCWSTR contentName, HAMSISESSION amsiSession, AMSI_RESULT* result);
HRESULT WINAPI AmsiScanString(HAMSICONTEXT amsiContext, LPCWSTR string, LPCWSTR contentName, HAMSISESSION amsiSession, AMSI_RESULT* result);

#ifdef __cplusplus
}
#endif
#endif
